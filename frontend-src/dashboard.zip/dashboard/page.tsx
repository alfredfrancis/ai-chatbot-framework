import React from "react";
import Image, { StaticImageData } from "next/image";
import book1 from "@/public/index-optimized/book-1.svg";
import chevronUp1 from "@/public/index-optimized/chevron-up-1.svg";
import coffee1 from "@/public/index-optimized/coffee-1.svg";
import ellipse4 from "@/public/index-optimized/ellipse-4.png";
import group from "@/public/index-optimized/group.png";
import home1 from "@/public/index-optimized/home-1.svg";
import messageSquare1 from "@/public/index-optimized/message-square-1.svg";
import "./Sidebar.css";

const Sidebar = () => {
  const menuItems = [
    { label: "Dashboard", icon: home1 },
    { label: "Tune ML", icon: home1 },
    { label: "Intents", icon: coffee1 },
    { label: "Chat Widget", icon: home1 },
    { label: "Entities", icon: book1 },
    { label: "Import Data", icon: home1 },
    { label: "Export Data", icon: home1 },
    { label: "Chat Widget", icon: messageSquare1 },
  ];

  return (
    <aside className="sidebar">
      <div className="sidebar-header">
        <h1 className="admin-panel">Admin Panel</h1>
      </div>
      <div className="sidebar-section">
        <h2 className="section-title">PROJECTS</h2>
        <p className="project-name">Default Project</p>
      </div>
      <nav className="menu">
        {menuItems.map((item, index) => (
          <div key={index} className="menu-item">
            <div className="menu-icon">
              <Image src={item.icon as StaticImageData} alt={item.label} />
            </div>
            <span className="menu-label">{item.label}</span>
          </div>
        ))}
      </nav>
      <div className="sidebar-section">
        <h2 className="section-title">SETTINGS</h2>
      </div>
      <div className="background-images">
        <Image className="chevron-up" alt="Chevron up" src={chevronUp1 as StaticImageData} />
        <Image className="ellipse" alt="Ellipse" src={ellipse4 as StaticImageData} />
        <Image className="group" alt="Group" src={group as StaticImageData} />
      </div>
    </aside>
  );
};

export default Sidebar;